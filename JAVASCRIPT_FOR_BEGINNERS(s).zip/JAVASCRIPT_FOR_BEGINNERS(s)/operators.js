// Arithmatic Operators
// let x = 2;
// let y =1;
// let z = x *y;
// let o = x / y;
// // modulus operator
// let q = x % y


// if (x%y==2){
//     console.log("the number is even")
// }

// else if(x%y == 0) {
//     console.log("neither even neither odd")
// }



// else{
//     console.log("it's an odd number")
// }

// and operator
// if(x===2 && y===2) {
//     console.log("condition is true")
// }



// if(x===2 || y===2 ){
//     console.log("condition is true as either one of the condition should be true")
// }


// if (x!==2){
//     console.log("x is 2")
// }

// += and -=









