let y = 5;
let x = --y;


console.log(y);
console.log(x);
console.log(y);

