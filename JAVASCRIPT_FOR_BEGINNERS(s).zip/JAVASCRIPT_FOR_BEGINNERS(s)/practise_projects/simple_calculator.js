// program to make a simple calculator

// take the operator input
//const operator =  windows.prompt("Enter operator (*,-,*,/)");


const operator = "+"

const number1 = 5

const number2 = 10

let result;

// using if else .. else if .. else

if(operator === '+'){
    result = number1 + number2
}


else if(operator === '-'){
    result = number1 - number2
}

else if(operator === '*'){
    result = number1 * number2
}

else {
    result = number1 / number2
}

// display the result

console.log(`${number1} ${operator} ${number2} = ${result} `)





