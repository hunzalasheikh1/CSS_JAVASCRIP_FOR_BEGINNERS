// a higher order function can take an argumnent as a function , or it can return a function or it does both

const calculator = (operator) =>{
    if(operator === '+'){
        return function  (a,b){
            console.log(a+b)
        }
    }

    if(operator === '-'){
        return function(p,q){
            console.log(p-q)
        }
    }

    if(operator === '*'){
        return function(u,v){
            console.log(u*v)
        }
    }

    if(operator === '/'){
        return function(n,m){
            if(m===0){
                return
            }
            else {
            console.log(n/m)
            }
        }
    }


    if(operator === '%'){
        return function(r,t){
            console.log(r%t)
        }
    }

    if(operator === '**'){
        return function(j,k){
            console.log(Math.pow(j,k))
        }
    }
}

calculator('/')(2,2)


x = ["boys","Bavascript","js"]

for(i=0; i < x.length  ; i++){
    if(x[i][0] === 'b' ||  x[i][0] === 'B')
    {console.log(x[i]) }

    
}

