//console.log("Hello World");

let x = "5";
let y = 10;
let z = 5;
let o = y +z;
let string1 = "JavaScrip Is ";
let string2 = "Easy";
let string3 = string1 + string2;
document.getElementById("demo").innerHTML = string3;
console.log(o);







