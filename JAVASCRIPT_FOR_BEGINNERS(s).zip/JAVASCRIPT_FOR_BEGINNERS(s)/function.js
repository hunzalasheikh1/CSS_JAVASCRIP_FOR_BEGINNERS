// let friends = [true,false,true,false];

// const makeLowerCase = (arr) => {
//     for(let i = 0; i< arr.length; i++) {
// if(typeof arr[i] === 'boolean'){
//    console.log("array is having a boolean")
// }
//     }
// }


// makeLowerCase(friends);

// console.log(friends[0]);

// while loop
