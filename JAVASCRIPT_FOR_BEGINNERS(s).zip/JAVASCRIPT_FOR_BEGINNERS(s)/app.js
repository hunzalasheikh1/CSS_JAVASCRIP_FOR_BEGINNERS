

function hello(JSON()){
    
    
}


function javscript(hello)


function functionName(parameter1, parameter2, parameter3) {
    // code to be executed
  }


  x = [1,2,3]

  function hello(x)