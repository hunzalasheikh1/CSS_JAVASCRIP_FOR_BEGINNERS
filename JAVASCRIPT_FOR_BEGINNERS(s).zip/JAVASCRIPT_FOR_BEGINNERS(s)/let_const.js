const x = 5;
const y = 10;
const z = 2;



console.log(x)
console.log(y);
console.log(z);