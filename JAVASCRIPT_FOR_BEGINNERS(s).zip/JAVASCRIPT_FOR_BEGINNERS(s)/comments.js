 //this is a single line comment
/* this is a multiple line commnet

  some lines

  */


 